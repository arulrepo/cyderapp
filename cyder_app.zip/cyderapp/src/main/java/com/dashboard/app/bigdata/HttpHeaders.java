package com.dashboard.app.bigdata;

import java.sql.Time;
import java.util.UUID;

public class HttpHeaders {

	public HttpHeaders(UUID id, String username, Time logindate, String role) {
		super();
		this.id = id;
		this.username = username;
		this.logindate = logindate;
		this.role = role;
	}

	private UUID id;

	private String username;

	private Time logindate;

	private String role;

	public UUID getId() {
		return id;
	}

	public void setId(UUID id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Time getLogindate() {
		return logindate;
	}

	public void setLogindate(Time logindate) {
		this.logindate = logindate;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

}
