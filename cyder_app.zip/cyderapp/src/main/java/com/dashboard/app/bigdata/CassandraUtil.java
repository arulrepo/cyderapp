package com.dashboard.app.bigdata;

import java.util.List;

import org.cassandraunit.utils.EmbeddedCassandraServerHelper;

import com.datastax.driver.core.ResultSet;
import com.datastax.driver.core.Row;
import com.datastax.driver.core.Session;

public class CassandraUtil {
	
	public static Session session;

	public static void createKeySpace(String keyspaceName) throws Exception {
		//startServer();
		CassandraConnecter client = new CassandraConnecter();
		client.connect("127.0.0.1", 9042);
		session = client.getSession();
		createSchema(keyspaceName, "SimpleStrategy", 1, session);
		ResultSet result = session.execute("SELECT * FROM system_schema.keyspaces;");
		List<Row> rowList = result.all();
		for (Row row : rowList) {
			System.out.println("row-----" + row);
		}
		//stopServer();

	}

	private static void createSchema(String keyspaceName, String replicationStrategy, int replicationFactor,
			Session session) {
		StringBuilder sb = new StringBuilder("CREATE KEYSPACE IF NOT EXISTS ").append(keyspaceName)
				.append(" WITH replication = {").append("'class':'").append(replicationStrategy)
				.append("','replication_factor':").append(replicationFactor).append("};");

		String query = sb.toString();
		session.execute(query);
	}

	private static void startServer() throws Exception {
		EmbeddedCassandraServerHelper.startEmbeddedCassandra(20000L);
	}

	private static void stopServer() {
		EmbeddedCassandraServerHelper.cleanEmbeddedCassandra();
	}
}
