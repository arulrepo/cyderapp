package com.dashboard.app.bigdata.repository;

import com.dashboard.app.bigdata.HttpHeaders;
import com.datastax.driver.core.Session;

public class HeadersRepository {

	private static final String TABLE_NAME = "httpheaders";
	private Session session;

	public HeadersRepository(Session session) {
		this.session = session;
	}

	public void createTable() {
		StringBuilder sb = new StringBuilder("CREATE TABLE IF NOT EXISTS ").append(TABLE_NAME).append("(")
				.append("id uuid PRIMARY KEY, ").append("username text,").append("logindate timestamp,")
				.append("role text);");
		String query = sb.toString();
		session.execute(query);
	}

	public void insert(HttpHeaders headers) {
		StringBuilder sb = new StringBuilder("INSERT INTO ").append(TABLE_NAME)
				.append("(id, username, logindate, role) ").append("VALUES (").append(headers.getId()).append(", '")
				.append(headers.getUsername()).append("', '").append(headers.getLogindate()).append("', '")
				.append(headers.getRole()).append("');");
		final String query = sb.toString();
		session.execute(query);
	}
}
