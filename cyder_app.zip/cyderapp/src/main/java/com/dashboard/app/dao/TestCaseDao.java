package com.dashboard.app.dao;

import java.util.List;

import com.dashboard.app.model.TestCase;


public interface TestCaseDao {

	List<TestCase> findAll();
	
	List<TestCase> findByProject(String projectName);
	
	TestCase findById(int id);
	
	void save(TestCase TestCase);
	
}
