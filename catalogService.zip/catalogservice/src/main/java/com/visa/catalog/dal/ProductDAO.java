package com.visa.catalog.dal;

import java.util.List;

import com.visa.catalog.domain.Product;

public interface ProductDAO {

	Product save(Product p);

	List<Product> findAll();

	Product findById(int id);

}