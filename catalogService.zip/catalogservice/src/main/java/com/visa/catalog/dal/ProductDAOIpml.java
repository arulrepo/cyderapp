package com.visa.catalog.dal;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.stereotype.Component;

import com.visa.catalog.domain.Product;

@Component
public class ProductDAOIpml implements ProductDAO {
	
	Map<Integer,Product> db = new ConcurrentHashMap<>();
	AtomicInteger idSeq = new AtomicInteger(0);
	
	//CRUD 
	
	/* (non-Javadoc)
	 * @see com.visa.catalog.dal.ProductDAO#save(com.visa.catalog.domain.Product)
	 */
	@Override
	public Product save(Product p) {
		int id = idSeq.incrementAndGet();
		p.setId(id);
		db.put(id, p);
		return p;
	}
	
	/* (non-Javadoc)
	 * @see com.visa.catalog.dal.ProductDAO#findAll()
	 */
	@Override
	public List<Product> findAll(){
		return new ArrayList<>(db.values());
	}
	
	/* (non-Javadoc)
	 * @see com.visa.catalog.dal.ProductDAO#findById(int)
	 */
	@Override
	public Product findById(int id) {
		return db.get(id);
	}

}
