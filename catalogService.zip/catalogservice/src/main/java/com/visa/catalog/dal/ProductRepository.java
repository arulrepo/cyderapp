package com.visa.catalog.dal;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.visa.catalog.domain.Product;

@Repository
public interface ProductRepository extends CrudRepository<Product, Integer> {
	
	List<Product> findAll();
	Product findById(int id);
	
	//Product findByPrice(float f);

}
