package com.dashboard.app.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends WebSecurityConfigurerAdapter {

	@Autowired
	RedirectURLHandler customSuccessHandler;

	@Autowired
	public void configureGlobalSecurity(AuthenticationManagerBuilder auth) throws Exception {
		auth.inMemoryAuthentication().withUser("ProjectManager").password("test123").roles("PROJ_ADMIN","QA_ADMIN","BA_ADMIN");
		auth.inMemoryAuthentication().withUser("QualityAnalyst").password("test123").roles("QA_ADMIN");
		auth.inMemoryAuthentication().withUser("BusinessAnalyst").password("test123").roles("BA_ADMIN");
	}

	@Override
	protected void configure(HttpSecurity http) throws Exception {
	  http.authorizeRequests()
	  	.antMatchers("/project/**").access("hasRole('PROJ_ADMIN')")
	  	.antMatchers("/issue/**").access("hasRole('PROJ_ADMIN') or hasRole('QA_ADMIN')")
	  	.antMatchers("/testcase/**").access("hasRole('PROJ_ADMIN') or hasRole('BA_ADMIN')")
	  	.and().formLogin().loginPage("/login").successHandler(customSuccessHandler)
	  	.usernameParameter("ssoId").passwordParameter("password")
	  	.and().csrf()
	  	.and().exceptionHandling().accessDeniedPage("/Access_Denied");
	}

}
